import { useState, useRef, useEffect, useCallback, type FormEvent } from 'react';
import { Mic, Send, Edit2, Trash2, Sparkles, X, Check, FileSpreadsheet, FileJson } from 'lucide-react';
import { toast } from 'sonner';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { useSpeechRecognition } from '@/hooks/use-speech-recognition';
import { parseExpenseText } from '@/lib/parser';
import { addRecords, getAllRecords } from '@/lib/storage';
import { exportCSV, exportJSON } from '@/lib/exporter';
import { APP_VERSION } from '@/lib/version';
import { CATEGORY_COLORS, CATEGORY_MAP, type IParsedRecord } from '@/data/account';
import { cn } from '@/lib/utils';

interface EditableRecord extends IParsedRecord {
  _id: string;
}

export default function RecordPage() {
  const [text, setText] = useState('');
  const [previewRecords, setPreviewRecords] = useState<EditableRecord[]>([]);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [isParsing, setIsParsing] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const {
    isListening,
    transcript,
    isSupported,
    error: speechError,
    startListening,
    stopListening,
    getFinalTranscript,
  } = useSpeechRecognition();

  // 语音识别实时同步到输入框（录音中就显示，便于用户看到识别进度）
  useEffect(() => {
    if (isListening && transcript) {
      setText(transcript);
    }
  }, [transcript, isListening]);

  // 语音停止后，确保最终文本填入输入框
  useEffect(() => {
    if (!isListening) {
      const finalText = getFinalTranscript();
      if (finalText && finalText.trim()) {
        setText(finalText.trim());
      }
    }
  }, [isListening, getFinalTranscript]);

  // 语音错误提示
  useEffect(() => {
    if (!speechError) return;

    if (speechError === 'not-allowed' || speechError === 'service-not-allowed') {
      toast.error('请允许麦克风权限后重试');
    } else if (speechError === 'no-speech') {
      toast.info('没有检测到语音，请再试一次');
    } else if (speechError === 'network') {
      toast.error('语音识别需要网络连接，请检查网络');
    } else {
      toast.error('语音识别失败，请改用文字输入');
    }
  }, [speechError]);

  /**
   * 调用解析引擎，将结果渲染为预览卡片
   * 统一入口：语音输入和文字输入都走这里
   */
  const handleParse = useCallback((inputText: string) => {
    const trimmed = inputText.trim();
    if (!trimmed) {
      toast.info('请输入消费内容');
      return;
    }

    setIsParsing(true);

    try {
      const results = parseExpenseText(trimmed);

      if (results.length === 0) {
        toast.error('没能识别出金额和分类，请检查文字是否包含消费金额');
        setPreviewRecords([]);
        setEditingId(null);
        return;
      }

      const editable: EditableRecord[] = results.map((r, i) => ({
        ...r,
        _id: `preview_${Date.now()}_${i}`,
      }));

      setPreviewRecords(editable);
      setEditingId(null);
      toast.success(`识别出 ${editable.length} 笔消费`);
    } catch (e) {
      toast.error('解析出错，请重试或手动输入');
      setPreviewRecords([]);
    } finally {
      setIsParsing(false);
    }
  }, []);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!text.trim()) {
      toast.info('请输入消费内容');
      return;
    }
    handleParse(text);
  };

  const handleMicClick = () => {
    if (!isSupported) {
      toast.error('当前浏览器不支持语音识别，请改用文字输入');
      return;
    }

    if (isListening) {
      // 用户点击停止：结束录音，文字已经在输入框里，不自动解析，等用户点解析按钮
      stopListening();
    } else {
      // 开始录音：清空之前的预览和输入
      setPreviewRecords([]);
      setEditingId(null);
      setText('');
      startListening();
    }
  };

  const handleSave = () => {
    if (previewRecords.length === 0) return;
    // 过滤掉金额为 0 的
    const validRecords = previewRecords.filter((r) => r.amount > 0);
    if (validRecords.length === 0) {
      toast.error('请填写有效的金额');
      return;
    }
    addRecords(validRecords);
    toast.success(`已记 ${validRecords.length} 笔账`);
    setPreviewRecords([]);
    setText('');
    setEditingId(null);
    inputRef.current?.focus();
  };

  const updateRecord = (id: string, updates: Partial<IParsedRecord>) => {
    setPreviewRecords((prev) =>
      prev.map((r) => (r._id === id ? { ...r, ...updates } : r)),
    );
  };

  const removeRecord = (id: string) => {
    setPreviewRecords((prev) => prev.filter((r) => r._id !== id));
  };

  const handleCategory1Change = (id: string, cat1: string) => {
    const subCats = CATEGORY_MAP[cat1] || [];
    const cat2 = subCats[0] || '其他';
    updateRecord(id, { category1: cat1, category2: cat2 });
  };

  return (
    <div className="flex min-h-screen flex-col px-5 pt-8 pb-6">
      {/* 顶部标题 + 导出按钮 */}
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-stone-800 tracking-tight">记一笔</h1>
          <p className="mt-1 text-sm text-stone-500">说话或打字，自动解析记账</p>
        </div>
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => {
              const records = getAllRecords();
              if (records.length === 0) {
                toast.info('暂无数据可导出');
                return;
              }
              try {
                exportCSV(records);
                toast.success('CSV 已导出');
              } catch {
                toast.error('导出失败');
              }
            }}
            className="flex h-9 w-9 items-center justify-center rounded-full bg-stone-100 text-stone-600 hover:bg-stone-200 transition-colors"
            aria-label="导出 CSV"
            title="导出 CSV"
          >
            <FileSpreadsheet className="h-4 w-4" />
          </button>
          <button
            onClick={() => {
              const records = getAllRecords();
              if (records.length === 0) {
                toast.info('暂无数据可导出');
                return;
              }
              try {
                exportJSON(records);
                toast.success('JSON 备份已导出');
              } catch {
                toast.error('导出失败');
              }
            }}
            className="flex h-9 w-9 items-center justify-center rounded-full bg-stone-100 text-stone-600 hover:bg-stone-200 transition-colors"
            aria-label="导出 JSON 备份"
            title="导出 JSON 备份"
          >
            <FileJson className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* 版本号 */}
      <div className="mb-2 text-center">
          <span className="text-[10px] text-stone-400">v{APP_VERSION}</span>
      </div>

      {/* 语音输入区 */}
      <div className="mb-8 flex flex-col items-center">
        <button
          onClick={handleMicClick}
          className={cn(
            'relative flex h-24 w-24 items-center justify-center rounded-full',
            'transition-all duration-200 ease-out',
            'active:scale-95',
            'min-h-[96px] min-w-[96px]',
            isListening
              ? 'bg-red-500 text-white shadow-xl shadow-red-300/60 scale-105'
              : 'bg-gradient-to-br from-amber-400 to-amber-600 text-white shadow-lg shadow-amber-300/50 hover:shadow-xl hover:shadow-amber-300/60 hover:scale-105',
          )}
          aria-label={isListening ? '停止录音' : '开始录音'}
        >
          <Mic className={cn('h-10 w-10', isListening && 'animate-pulse')} strokeWidth={2} />
          {isListening && (
            <>
              <motion.span
                className="absolute inset-0 rounded-full border-2 border-red-400"
                animate={{ scale: [1, 1.35, 1], opacity: [0.7, 0, 0.7] }}
                transition={{ duration: 1.8, repeat: Infinity, ease: 'easeInOut' }}
              />
              <motion.span
                className="absolute inset-0 rounded-full border-2 border-red-300"
                animate={{ scale: [1, 1.55, 1], opacity: [0.5, 0, 0.5] }}
                transition={{ duration: 1.8, repeat: Infinity, ease: 'easeInOut', delay: 0.6 }}
              />
            </>
          )}
        </button>
        <p className="mt-4 text-sm text-stone-600 font-medium">
          {isListening ? '正在聆听，点击按钮完成' : '点击麦克风，说一句话记账'}
        </p>
        {transcript && isListening && (
          <p className="mt-3 max-w-full px-4 text-center text-sm text-stone-700 min-h-[1.5em] leading-relaxed">
            {transcript}
            <span className="inline-block w-0.5 h-4 bg-red-500 ml-0.5 align-middle animate-pulse" />
          </p>
        )}
        {!isListening && text && (
          <p className="mt-3 max-w-full px-4 text-center text-sm text-stone-700 leading-relaxed">
            {text}
          </p>
        )}
      </div>

      {/* 分隔线 */}
      <div className="mb-6 flex items-center gap-3">
        <div className="h-px flex-1 bg-stone-200/80" />
        <span className="text-xs text-stone-400">或手动输入</span>
        <div className="h-px flex-1 bg-stone-200/80" />
      </div>

      {/* 文字输入区 */}
      <form onSubmit={handleSubmit} className="mb-8">
        <div className="flex gap-2">
          <Input
            ref={inputRef}
            type="text"
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="比如：今天打车花了35块"
            className="h-12 flex-1 bg-white/90 border-stone-200 focus-visible:ring-amber-400/50 text-base"
          />
          <Button
            type="submit"
            className="h-12 px-5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white font-medium shadow-sm"
            disabled={isParsing || !text.trim()}
          >
            {isParsing ? (
              <>
                <span className="h-4 w-4 border-2 border-white/40 border-t-white rounded-full animate-spin mr-1.5" />
                解析中
              </>
            ) : (
              <>
                <Send className="h-4 w-4 mr-1.5" />
                解析
              </>
            )}
          </Button>
        </div>
        <p className="mt-2 text-xs text-stone-400">
          支持多笔，用句号/分号/换行分隔，如"打车35。午饭28"
        </p>
      </form>

      {/* 解析预览区 */}
      <AnimatePresence mode="popLayout">
        {previewRecords.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3 }}
            className="space-y-3"
          >
            <div className="flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-amber-600" />
              <h2 className="text-sm font-medium text-stone-700">
                解析结果 ({previewRecords.length} 笔)
              </h2>
            </div>

            {previewRecords.map((record, index) => (
              <PreviewCard
                key={record._id}
                record={record}
                index={index}
                isEditing={editingId === record._id}
                onEditToggle={() =>
                  setEditingId(editingId === record._id ? null : record._id)
                }
                onUpdate={(updates) => updateRecord(record._id, updates)}
                onRemove={() => removeRecord(record._id)}
                onCategory1Change={(cat1) =>
                  handleCategory1Change(record._id, cat1)
                }
              />
            ))}

            <Button
              onClick={handleSave}
              className="w-full h-12 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white text-base font-semibold shadow-md shadow-amber-300/30"
              size="lg"
            >
              保存记账
            </Button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 空状态提示 */}
      {previewRecords.length === 0 && !isListening && !text && (
        <div className="mt-8 flex flex-col items-center text-center">
          <div className="mb-3 text-4xl">📒</div>
          <p className="text-sm text-stone-400">
            点击上方麦克风说话
            <br />
            或输入一笔消费开始记账
          </p>
        </div>
      )}

      {/* 不支持语音时的提示 */}
      {!isSupported && (
        <div className="mt-4 rounded-lg bg-amber-100/50 px-3 py-2 text-xs text-amber-700">
          当前浏览器不支持语音识别，可使用文字输入
        </div>
      )}

      {/* 编辑对话框（用于小屏完整编辑） */}
      <EditDialog
        open={!!editingId}
        record={previewRecords.find((r) => r._id === editingId)}
        onClose={() => setEditingId(null)}
        onUpdate={(updates) => {
          if (editingId) updateRecord(editingId, updates);
        }}
        onCategory1Change={(cat1) => {
          if (editingId) handleCategory1Change(editingId, cat1);
        }}
        onRemove={() => {
          if (editingId) {
            removeRecord(editingId);
            setEditingId(null);
          }
        }}
      />
    </div>
  );
}

/* ---------- PreviewCard ---------- */

interface PreviewCardProps {
  record: EditableRecord;
  index: number;
  isEditing: boolean;
  onEditToggle: () => void;
  onUpdate: (updates: Partial<IParsedRecord>) => void;
  onRemove: () => void;
  onCategory1Change: (cat1: string) => void;
}

function PreviewCard({
  record,
  index,
  isEditing,
  onEditToggle,
  onUpdate,
  onRemove,
  onCategory1Change,
}: PreviewCardProps) {
  const colors = CATEGORY_COLORS[record.category1] || CATEGORY_COLORS['生活'];

  return (
    <motion.div
      initial={{ opacity: 0, x: -10 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.05 }}
    >
      <Card className={cn('border-amber-200/60 bg-white/70 backdrop-blur-sm')}>
        <CardContent className="p-3">
          <div className="flex items-start gap-3">
            {/* 分类色标 */}
            <div
              className={cn(
                'mt-1 h-3 w-3 shrink-0 rounded-full',
                colors.dot,
              )}
            />

            {/* 内容 */}
            <div className="min-w-0 flex-1">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 min-w-0">
                  <span className={cn('text-sm font-medium', colors.text)}>
                    {record.category1}
                  </span>
                  <span className="text-xs text-stone-500">· {record.category2}</span>
                </div>
                <span className="text-lg font-semibold text-stone-800 shrink-0">
                  ¥{record.amount.toFixed(2)}
                </span>
              </div>

              {record.remark && (
                <p className="mt-1 text-xs text-stone-500 truncate">
                  {record.remark}
                </p>
              )}

              {/* 日期显示（非当天才显示，减少视觉噪音） */}
              {record.date && (
                <p className="mt-1 text-xs text-stone-400">
                  📅 {record.date}
                </p>
              )}

              {/* 编辑状态展开 */}
              {isEditing && (
                <div className="mt-3 space-y-2 pt-2 border-t border-amber-100">
                  <div className="flex gap-2">
                    <div className="flex-1">
                      <label className="text-xs text-stone-500 mb-1 block">金额</label>
                      <Input
                        type="number"
                        step="0.01"
                        min="0"
                        value={record.amount}
                        onChange={(e) =>
                          onUpdate({ amount: parseFloat(e.target.value) || 0 })
                        }
                        className="h-9 text-sm bg-white"
                      />
                    </div>
                    <div className="flex-1">
                      <label className="text-xs text-stone-500 mb-1 block">日期</label>
                      <Input
                        type="date"
                        value={record.date || ''}
                        onChange={(e) =>
                          onUpdate({ date: e.target.value || undefined })
                        }
                        className="h-9 text-sm bg-white"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-xs text-stone-500 mb-1 block">
                        一级分类
                      </label>
                      <Select
                        value={record.category1}
                        onValueChange={onCategory1Change}
                      >
                        <SelectTrigger className="h-9 text-sm bg-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {Object.keys(CATEGORY_MAP).map((cat) => (
                            <SelectItem key={cat} value={cat} className="text-sm">
                              {cat}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <label className="text-xs text-stone-500 mb-1 block">
                        二级分类
                      </label>
                      <Select
                        value={record.category2}
                        onValueChange={(v) => onUpdate({ category2: v })}
                      >
                        <SelectTrigger className="h-9 text-sm bg-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {(CATEGORY_MAP[record.category1] || []).map((cat) => (
                            <SelectItem key={cat} value={cat} className="text-sm">
                              {cat}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div>
                    <label className="text-xs text-stone-500 mb-1 block">备注</label>
                    <Input
                      type="text"
                      value={record.remark}
                      onChange={(e) => onUpdate({ remark: e.target.value })}
                      placeholder="添加备注"
                      className="h-9 text-sm bg-white"
                    />
                  </div>
                  <div className="flex justify-end">
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={onRemove}
                      className="h-8 text-xs"
                    >
                      <Trash2 className="h-3 w-3 mr-1" />
                      删除
                    </Button>
                  </div>
                </div>
              )}
            </div>

            {/* 编辑按钮 */}
            <button
              onClick={onEditToggle}
              className="h-8 w-8 shrink-0 flex items-center justify-center rounded-md text-stone-400 hover:text-stone-600 hover:bg-amber-50 min-h-[44px] min-w-[44px]"
              aria-label="编辑"
            >
              <Edit2 className="h-4 w-4" />
            </button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

/* ---------- EditDialog ---------- */

interface EditDialogProps {
  open: boolean;
  record: EditableRecord | undefined;
  onClose: () => void;
  onUpdate: (updates: Partial<IParsedRecord>) => void;
  onCategory1Change: (cat1: string) => void;
  onRemove: () => void;
}

function EditDialog({
  open,
  record,
  onClose,
  onUpdate,
  onCategory1Change,
  onRemove,
}: EditDialogProps) {
  if (!record) return null;

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-sm mx-4">
        <DialogHeader>
          <DialogTitle>编辑记录</DialogTitle>
            <DialogDescription>修改金额、日期、分类或备注</DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div>
            <label className="text-xs text-stone-500 mb-1 block">金额 (元)</label>
            <Input
              type="number"
              step="0.01"
              min="0"
              value={record.amount}
              onChange={(e) =>
                onUpdate({ amount: parseFloat(e.target.value) || 0 })
              }
              className="h-10"
            />
          </div>
          <div>
            <label className="text-xs text-stone-500 mb-1 block">日期</label>
            <Input
              type="date"
              value={record.date || ''}
              onChange={(e) =>
                onUpdate({ date: e.target.value || undefined })
              }
              className="h-10"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-stone-500 mb-1 block">一级分类</label>
              <Select value={record.category1} onValueChange={onCategory1Change}>
                <SelectTrigger className="h-10">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.keys(CATEGORY_MAP).map((cat) => (
                    <SelectItem key={cat} value={cat}>
                      {cat}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-xs text-stone-500 mb-1 block">二级分类</label>
              <Select
                value={record.category2}
                onValueChange={(v) => onUpdate({ category2: v })}
              >
                <SelectTrigger className="h-10">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {(CATEGORY_MAP[record.category1] || []).map((cat) => (
                    <SelectItem key={cat} value={cat}>
                      {cat}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div>
            <label className="text-xs text-stone-500 mb-1 block">备注</label>
            <Input
              type="text"
              value={record.remark}
              onChange={(e) => onUpdate({ remark: e.target.value })}
              placeholder="添加备注"
              className="h-10"
            />
          </div>
        </div>
        <DialogFooter className="flex-col sm:flex-row gap-2">
          <Button
            variant="destructive"
            onClick={onRemove}
            className="w-full sm:w-auto"
          >
            <Trash2 className="h-4 w-4 mr-1" />
            删除
          </Button>
          <Button
            onClick={onClose}
            className="w-full sm:w-auto bg-amber-600 hover:bg-amber-700"
          >
            完成
          </Button>
        </DialogFooter>
        <button
          onClick={onClose}
          className="absolute right-4 top-4 h-8 w-8 flex items-center justify-center rounded-md text-stone-400 hover:text-stone-600 min-h-[44px] min-w-[44px]"
          aria-label="关闭"
        >
          <X className="h-4 w-4" />
        </button>
      </DialogContent>
    </Dialog>
  );
}
